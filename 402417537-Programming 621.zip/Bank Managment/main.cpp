#include <iostream>
#include <fstream>
#include <vector>
#include <ctime>
#include <cstdlib>
#include "Account.h"
#include "Teller.h"
#include "Helper.h"
#include "FileHandler.h"

using namespace std;

// Here are the global lists we'll use for branches, tellers, accounts, and transactions
vector<Branch> branches;
vector<Teller> tellers;
vector<Account*> accounts;
vector<string> transactionHistory;

// Function declarations
void tellerLogin();
void customerLogin();
void tellerMenu(string tellerBranch);
void customerMenu(Account &loggedCustomer);
void registerCustomer(string tellerBranch);
void viewCustomerDetails();
void deposit(Account &acc);
void withdraw(Account &acc);
void transfer(Account &acc);
void viewStatement(Account &acc);
void changePin(Account &acc);
void generateReport(string branchCode);
void calculateInterest();

int main() {
    srand(time(0)); // Get things random with a fresh seed

    // Let�s set up some branches
    Branch b1;
    b1.branchCode = "BR001";
    b1.branchName = "Johannesburg Main";
    b1.location = "123 Commissioner Street";
    branches.push_back(b1);

    Branch b2;
    b2.branchCode = "BR002";
    b2.branchName = "Cape Town Central";
    b2.location = "45 Adderley Street";
    branches.push_back(b2);

    Branch b3;
    b3.branchCode = "BR003";
    b3.branchName = "Durban North";
    b3.location = "78 Florida Road";
    branches.push_back(b3);

    // Toss in some tellers
    tellers.push_back(Teller("T001", "John Doe", "pass123", "BR001"));
    tellers.push_back(Teller("T002", "Jane Smith", "pass456", "BR002"));
    tellers.push_back(Teller("T003", "Mike Brown", "pass789", "BR003"));

    loadData();

    int choice;
    do {
        cout << "\n**** STANDARD BANK SYSTEM ***\n";
        cout << "1. Teller Login\n";
        cout << "2. Customer Login\n";
        cout << "3. Exit\n";
        cout << "Choice: ";
        cin >> choice;

        if(choice == 1) {
            tellerLogin();
        } else if(choice == 2) {
            customerLogin();
        }

    } while(choice != 3);

    saveData();
    cout << "System shut down.\n";
    return 0;
}

// Handle teller login and unlock teller features
void tellerLogin() {
    string id, password;
    int attempts = 0;

    while(attempts < 3) {
        cout << "\nTeller ID: ";
        cin >> id;
        cout << "Password: ";
        cin >> password;

        for(int i = 0; i < tellers.size(); i++) {
            if(tellers[i].tellerID == id && simpleEncrypt(password) == tellers[i].passwordEncrypted) {
                cout << "\nLogin successful! Welcome, " << tellers[i].name << endl;
                tellerMenu(tellers[i].branchCode);
                return;
            }
        }
        attempts++;
        cout << "Wrong Details! Attempts left: " << 3 - attempts << endl;
    }
    cout << " Locked. Too many failed attempts. \n";
}

// Customer login
void customerLogin() {
    string accNum, pin;
    int attempts = 0;

    while(attempts < 3) {
        cout << "\nAccount Number: ";
        cin >> accNum;
        cout << "PIN: ";
        cin >> pin;

        for(int i = 0; i < accounts.size(); i++) {
            if(accounts[i]->getAccNumber() == accNum && simpleEncrypt(pin) == accounts[i]->getPinEncrypted()) {
                cout << "\nLogin successful! Welcome " << accounts[i]->getName() << endl;
                customerMenu(*accounts[i]);
                return;
            }
        }
        attempts++;
        cout << "Wrong Details! Attempts left: " << 3 - attempts << endl;
    }
    cout << " Locked. Too many failed attempts.\n";
}

// Register a new customer. Teller provides the info, bank sets things up.
void registerCustomer(string tellerBranch) {
    string accountType;
    double initialDeposit;

    cout << "\nREGISTER NEW CUSTOMER\n";
    cin.ignore();

    string name, idNumber, contact, email, address, dob;

    cout << "Full Name: ";
    getline(cin, name);

    cout << "SA ID Number (13 digits): ";
    cin >> idNumber;
    if(!validateSAID(idNumber)) {
        cout << "Invalid ID!\n";
        return;
    }

    cout << "Contact Number: ";
    cin >> contact;

    cout << "Email: ";
    cin >> email;
    if(!validateEmail(email)) {
        cout << "Invalid email!\n";
        return;
    }

    cin.ignore();
    cout << "Physical Address: ";
    getline(cin, address);

    cout << "Date of Birth (DD/MM/YYYY): ";
    cin >> dob;

    cout << "Account Type (Savings / Cheque / Fixed / Student): ";
    cin >> accountType;

    cout << "Initial Deposit (R): ";
    cin >> initialDeposit;

    Account* newAccount = NULL;

    if(accountType == "Savings") {
        if(initialDeposit < 100) {
            cout << "Savings needs minimum R100!\n";
            return;
        }
        newAccount = new SavingsAccount();
    } else if(accountType == "Cheque") {
        newAccount = new ChequeAccount();
    } else if(accountType == "Fixed") {
        if(initialDeposit < 1000) {
            cout << "Fixed deposit needs minimum R1000!\n";
            return;
        }
        newAccount = new FixedDepositAccount();
        int term;
        cout << "Enter term in months (12/24/36): ";
        cin >> term;
        FixedDepositAccount* f = (FixedDepositAccount*)newAccount;
        f->setTerm(term);
    } else if(accountType == "Student") {
        newAccount = new StudentAccount();
    } else {
        cout << "Invalid account type!\n";
        return;
    }

    // Now, let's generate account info and PIN
    string accNum = generateAccNumber(tellerBranch);
    string pin = generateRandomPin();

    newAccount->setAccNumber(accNum);
    newAccount->setName(name);
    newAccount->setIdNumber(idNumber);
    newAccount->setContact(contact);
    newAccount->setEmail(email);
    newAccount->setAddress(address);
    newAccount->setDob(dob);
    newAccount->setBal(initialDeposit);
    newAccount->setBranchCode(tellerBranch);
    newAccount->setPinEncrypted(simpleEncrypt(pin));

    accounts.push_back(newAccount);

    cout << "\n*** ACCOUNT CREATED ***\n";
    cout << "Account Number: " << accNum << endl;
    cout << "Account Type: " << newAccount->getAccountType() << endl;
    cout << "PIN: " << pin << endl;
    cout << "PLEASE SAVE THIS PIN!\n";

    saveData();
}

// Quick lookup for customer details
void viewCustomerDetails() {
    string accNum;
    cout << "Enter Account Number: ";
    cin >> accNum;

    for(int i = 0; i < accounts.size(); i++) {
        if(accounts[i]->getAccNumber() == accNum) {
            accounts[i]->displayInfo();
            return;
        }
    }
    cout << "Account not found!\n";
}

// Branch report for tellers: who's got what, and how much
void generateReport(string branchCode) {
    cout << "\n--- BRANCH REPORT FOR " << branchCode << " =====\n";
    double totalBalance = 0;
    int customerCount = 0;

    for(int i = 0; i < accounts.size(); i++) {
        if(accounts[i]->getBranchCode() == branchCode) {
            customerCount++;
            totalBalance += accounts[i]->getBal();
            cout << accounts[i]->getAccNumber() << " | " << accounts[i]->getName() << " | R" << accounts[i]->getBal() << endl;
        }
    }

    cout << "\nTotal Customers: " << customerCount << endl;
    cout << "Total Balance: R" << totalBalance << endl;
}

// Interest calculation -- applies to eligible accounts
void calculateInterest() {
    cout << "\n**** INTEREST CALCULATION ****\n";
    int accountsUpdated = 0;

    for(int i = 0; i < accounts.size(); i++) {
        double rate = accounts[i]->getInterestRate();
        if(rate > 0) {
            double interest = accounts[i]->getBal() * rate;
            accounts[i]->setBal(accounts[i]->getBal() + interest);
            accountsUpdated++;
            cout << accounts[i]->getAccNumber() << ": +R" << interest << endl;

            string trans = "Interest: +R" + toStr(interest);
            transactionHistory.push_back(trans);
        }
    }

    cout << "Interest added to " << accountsUpdated << " accounts.\n";
    saveData();
    saveTransactionsToFile();
}

// Deposits: add money to account, track it
void deposit(Account &acc) {
    double amount;
    cout << "Amount: R";
    cin >> amount;

    if(amount > 0) {
        acc.setBal(acc.getBal() + amount);
        transactionHistory.push_back("Deposit: +R" + toStr(amount));
        cout << "Deposit successful!\n";
        saveData();
        saveTransactionsToFile();
    } else {
        cout << "Invalid amount!\n";
    }
}

// Withdrawals: take money out, don�t overdraw
void withdraw(Account &acc) {
    double amount;
    cout << "Amount: R";
    cin >> amount;

    if(amount > 0 && amount <= acc.getBal()) {
        acc.setBal(acc.getBal() - amount);
        transactionHistory.push_back("Withdrawal: -R" + toStr(amount));
        cout << "Withdrawal successful!\n";
        saveData();
        saveTransactionsToFile();
    } else {
        cout << "Insufficient funds!\n";
    }
}

// Transfers: move money between accounts
void transfer(Account &acc) {
    string targetAcc;
    double amount;

    cout << "Target Account: ";
    cin >> targetAcc;
    cout << "Amount: R";
    cin >> amount;

    for(int i = 0; i < accounts.size(); i++) {
        if(accounts[i]->getAccNumber() == targetAcc && amount > 0 && amount <= acc.getBal()) {
            acc.setBal(acc.getBal() - amount);
            accounts[i]->setBal(accounts[i]->getBal() + amount);
            transactionHistory.push_back("Transfer: -R" + toStr(amount) + " to " + targetAcc);
            cout << "Transfer successful!\n";
            saveData();
            saveTransactionsToFile();
            return;
        }
    }
    cout << "Transfer failed!\n";
}

// Full account statement for customer, show last transactions
void viewStatement(Account &acc) {
    cout << "\n--- STATEMENT for " << acc.getAccNumber() << " =====\n";
    cout << "Balance: R" << acc.getBal() << endl;
    cout << "\nLast 10 transactions:\n";

    int start = transactionHistory.size() - 10;
    if(start < 0) start = 0;
    for(int i = start; i < transactionHistory.size(); i++) {
        cout << transactionHistory[i] << endl;
    }
}

// Change your PIN, simple as that
void changePin(Account &acc) {
    string oldPin, newPin;
    cout << "Current PIN: ";
    cin >> oldPin;

    if(simpleEncrypt(oldPin) != acc.getPinEncrypted()) {
        cout << "Incorrect PIN!\n";
        return;
    }

    cout << "New 5-digit PIN: ";
    cin >> newPin;

    if(newPin.length() != 5) {
        cout << "PIN must be 5 digits!\n";
        return;
    }

    acc.setPinEncrypted(simpleEncrypt(newPin));
    cout << "PIN changed!\n";
    saveData();
}

// Teller menu -- pick what to do, loop until logout
void tellerMenu(string tellerBranch) {
    int choice;
    do {
        cout << "\n TELLER MENU [" << tellerBranch << "] =====\n";
        cout << "1. Register Customer\n";
        cout << "2. View Customer Details\n";
        cout << "3. Branch Report\n";
        cout << "4. View Branches\n";
        cout << "5. Calculate Interest\n";
        cout << "6. Export to CSV\n";
        cout << "7. Backup\n";
        cout << "8. Restore\n";
        cout << "9. Logout\n";
        cout << "Choice: ";
        cin >> choice;

        if(choice == 1) { registerCustomer(tellerBranch); }
        else if(choice == 2) { viewCustomerDetails(); }
        else if(choice == 3) { generateReport(tellerBranch); }
        else if(choice == 4) {
            for(int i = 0; i < branches.size(); i++) {
                cout << branches[i].branchCode << " - " << branches[i].branchName << endl;
            }
        }
        else if(choice == 5) { calculateInterest(); }
        else if(choice == 6) {
            int csvChoice;
            cout << "1.Customers 2.Transactions 3.Branch Report: ";
            cin >> csvChoice;
            if(csvChoice == 1) { exportCustomersToCSV(); }
            else if(csvChoice == 2) { exportTransactionsToCSV(); }
            else if(csvChoice == 3) { exportBranchReportToCSV(); }
        }
        else if(choice == 7) { backupData(); }
        else if(choice == 8) { recoverFromBackup(); }
    } while(choice != 9);
}

// Customer menu -- show their options, keep looping until logout
void customerMenu(Account &loggedCustomer) {
    int choice;
    do {
        cout << "\n CUSTOMER MENU \n";
        cout << "Account: " << loggedCustomer.getAccountType() << endl;
        cout << "1. Balance\n";
        cout << "2. Deposit\n";
        cout << "3. Withdraw\n";
        cout << "4. Transfer\n";
        cout << "5. Statement\n";
        cout << "6. Change PIN\n";
        cout << "7. Logout\n";
        cout << "Choice: ";
        cin >> choice;

        if(choice == 1) { cout << "Balance: R" << loggedCustomer.getBal() << endl; }
        else if(choice == 2) { deposit(loggedCustomer); }
        else if(choice == 3) { withdraw(loggedCustomer); }
        else if(choice == 4) { transfer(loggedCustomer); }
        else if(choice == 5) { viewStatement(loggedCustomer); }
        else if(choice == 6) { changePin(loggedCustomer); }
    } while(choice != 7);
}

