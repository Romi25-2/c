#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <fstream>
#include <cstring>
#include <cstdlib>
#include <ctime>

using namespace std;

class Customer : public Account
{
private:
    char name[50];
    char idNumber[20];
    char contact[15];
    char email[50];
    char address[100];
    char dob[15];
    char branchCode[10];
    char pinEncrypted[20];

public:
    void registerCustomer();

    string generateAccountNumber();
    string generatePIN();
    string encryptPIN(string pin);

    void showCustomer();

    const char* getAcc();
    const char* getPIN();
};

#endif // CUSTOMER_H
