#ifndef FILEHANDLER_H
#define FILEHANDLER_H

#include <vector>
#include <string>
using namespace std;

// Function declarations
void loadData();
void saveData();
void saveTransactionsToFile();
void loadTransactionsFromFile();
void backupData();
void recoverFromBackup();
void exportCustomersToCSV();
void exportTransactionsToCSV();
void exportBranchReportToCSV();

#endif // FILEHANDLER_H

