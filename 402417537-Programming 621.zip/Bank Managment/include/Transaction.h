#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <iostream>
#include <fstream>
#include <cstring>
#include "Customer.h"

using namespace std;

class Transaction
{
    public:
    static bool verifyPIN(const char* acc);

    static void deposit();
    static void withdraw();
    static void transfer();
    static void viewStatement();
};

#endif // TRANSACTION_H
