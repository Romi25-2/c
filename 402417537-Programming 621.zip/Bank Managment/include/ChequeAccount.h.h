#ifndef CHEQUEACCOUNT_H_H
#define CHEQUEACCOUNT_H_H

#include <Account.h>


class ChequeAccount.h : public Account
{
    public:
       void overdraftInfo();
};

#endif // CHEQUEACCOUNT_H_H
