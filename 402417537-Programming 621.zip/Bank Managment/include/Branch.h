#ifndef BRANCH_H
#define BRANCH_H

#include <iostream>
using namespace std;

class Branch
{
    public:
        void setBranch(int code, const char* name, const char* loc, int emp, double dep);

        int getCode();
        const char* getName();
        const char* getLocation();
        int getEmployees();
        double getDeposits();

        void displayBranch();

    private:
        int branchCode;
        char branchName[30];
        char location[50];
        int numEmployees;
        double totalDeposits;

};

#endif // BRANCH_H
