#ifndef HELPER_H
#define HELPER_H

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class Account;

// Branch information
struct Branch {
    string branchCode;
    string branchName;
    string location;
};

// These are our global containers
extern vector<Branch> branches;
extern vector<Account*> accounts;
extern vector<string> transactionHistory;

// Function declarations
string toStr(double num);
string simpleEncrypt(string txt);
string generateAccNumber(string branchCode);
string generateRandomPin();
bool validateSAID(string id);
bool validateEmail(string email);

#endif // HELPER_H
