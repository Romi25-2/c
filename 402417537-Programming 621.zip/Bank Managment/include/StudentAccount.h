#ifndef STUDENTACCOUNT_H
#define STUDENTACCOUNT_H

#include <Account.h>


class StudentAccount : public Account
{
    public:
         void studentRules();
};

#endif // STUDENTACCOUNT_H
