#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <iostream>
#include <string>
using namespace std;

// Basic Account class
class Account {
protected:
    string accNumber, name, idNumber, contact, email, address, dob, branchCode;
    double bal;
    string pinEncrypted;

public:
    Account();
    virtual ~Account() { }

    // Getters
    string getAccNumber();
    string getName();
    string getIdNumber();
    string getContact();
    string getEmail();
    string getAddress();
    string getDob();
    double getBal();
    string getBranchCode();
    string getPinEncrypted();

    // Setters
    void setAccNumber(string num);
    void setName(string n);
    void setIdNumber(string id);
    void setContact(string c);
    void setEmail(string mail);
    void setAddress(string addr);
    void setDob(string date);
    void setBal(double b);
    void setBranchCode(string code);
    void setPinEncrypted(string p);

    virtual string getAccountType();
    virtual double getInterestRate();
    virtual void displayInfo();
};

// Savings Account (inherits from Account)
class SavingsAccount : public Account {
public:
    string getAccountType();
    double getInterestRate();
    double getMinimumBalance();
    void displayInfo();
};

// Cheque Account (inherits from Account)
class ChequeAccount : public Account {
public:
    string getAccountType();
    double getInterestRate();
    double getMinimumBalance();
    void displayInfo();
};

// Fixed Deposit Account (inherits from Account)
class FixedDepositAccount : public Account {
private:
    int termMonths;
public:
    FixedDepositAccount();
    string getAccountType();
    double getInterestRate();
    double getMinimumBalance();
    void setTerm(int months);
    int getTerm();
    void displayInfo();
};

// Student Account (inherits from Account)
class StudentAccount : public Account {
public:
    string getAccountType();
    double getInterestRate();
    double getMinimumBalance();
    void displayInfo();
};

#endif // ACCOUNT_H
