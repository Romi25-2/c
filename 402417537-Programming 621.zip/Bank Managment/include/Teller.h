#ifndef TELLER_H
#define TELLER_H

#include <iostream>
#include <string>
using namespace std;

class Teller {
public:
    string tellerID;
    string name;
    string passwordEncrypted;
    string branchCode;

    Teller();
    Teller(string id, string n, string pass, string branch);
};


#endif // TELLER_H
