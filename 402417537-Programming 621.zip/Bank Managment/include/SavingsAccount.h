#ifndef SAVINGSACCOUNT_H
#define SAVINGSACCOUNT_H

#include <Account.h>


class SavingsAccount : public Account
{
public:
    void interestNote();

};

#endif // SAVINGSACCOUNT_H
