#ifndef ACCOUNT_H_H
#define ACCOUNT_H_H


class Account.h
{
    public:
        Account.h();
        virtual ~Account.h();

    protected:

    private:
};

#endif // ACCOUNT_H_H
