#ifndef FIXEDDEPOSITACCOUNT_H
#define FIXEDDEPOSITACCOUNT_H

#include <Account.h>


class FixedDepositAccount : public Account
{
    public:
        void lockPeriodInfo();
};

#endif // FIXEDDEPOSITACCOUNT_H
