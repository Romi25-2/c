MULTI-BRANCH BANKING MANAGEMENT SYSTEM
README.txt

---

1. INTRODUCTION

---

This program is a console-based banking management system programmed using C++.
The program demonstrates various banking processes, including registering customers, processing transactions, handling tellers' duties, and producing reports.

The system has been created to satisfy the requirements for the Programming 621 module.

---

2. HOW TO COMPILE AND RUN THE PROGRAM

---

To compile and execute the system using Code::Blocks:

1. Launch Code::Blocks
2. Create a new blank project
3. Import all the .cpp and .h files into the project
4. Build and Execute the project (F9)

Ensure that all the files have been put in one folder:

* Main.cpp
* Account.cpp / Account.h
* Teller.cpp / Teller.h
* Helper.cpp / Helper.h
* FileHandler.cpp / FileHandler.h

---

3. DEFAULT TELLER LOGIN CREDENTIALS

---

Use any of the following tellers' login credentials to access the banking system:

* Username: T001
* Password: pass123
* Branch: BR001

* Username: T002
* Password: pass456
* Branch: BR002

* Username: T003
* Password: pass789
* Branch: BR003

Please note that passwords are always in encoded format in the banking system.

---

4. SYSTEM'S FEATURES

---

4.1 Tellers' Features
Once logged in, a teller can perform the following operations:

* Registration of customer accounts
* Displaying customer information
* Processing transactions
* Producing branch reports
* Listing branches
* Interest calculation
* Data export in CSV format
* Data backup and restoration

4.2 Customers' Features
Once logged in, a customer can perform the following operations:

* View account balance
* Deposit cash
* Withdraw cash
* Transfer funds between accounts
* Print account statement
* Modify PIN

---

5. HOW TO REGISTER A NEW CUSTOMER ACCOUNT

---

Step 1: Sign in as a teller

Step 2: Choose "Register Customer" option

Step 3: Fill in all required data:

   * Name
   * ID Number (13 digits)
   * Phone number
   * Email
   * Address
   * Date of Birth
   * Type of account
   * Initial deposit

Step 4: Automatically, the system will create:

   * Account Number
   * 5 digit long PIN

Note: The PIN is displayed once, and you should save it.

---
6. LOGIN

To LOGIN in as a customer:

Choose "Customer Login" and type in your account number, which should look like this: ACC-BR001-10001.
PIN

Customers can only
 try to log in three times before being locked out.

 7. TRANSACTIONS

The system can do:

Deposit, withdraw, and transfer

Every transaction changes the account balance and is saved in the transaction history.


8.FILE STORAGE
 The system uses files to store data:
 customers.dat → stores customer accounts
  transactions.dat → stores transaction history
   backup_customers.dat → backup file
    backup_transactions.dat → backup file
     CSV files → exported reports
     Data is automatically saved and loaded when the system starts or exits.

9.ACCOUNT TYPES
The system includes four account types:
Savings Account (3.5% interest, minimum balance required)
Cheque Account (no interest)
Fixed Deposit Account (7.5% interest, minimum deposit required)
Student Account (low interest, no minimum balance)

10. MORE FEATURES
Calculating interest for accounts that qualify
Operations at the branch level
Searching and reporting.
Exporting data to CSV files
System for backing up and restoring

11. NOTES
A simple encryption method is used to encrypt all PINs and passwords.
ID numbers and email addresses are checked for validity.
This system is not a real banking system; it is meant to help people lear
