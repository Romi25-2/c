#include "ChequeAccount.h.h"

void ChequeAccount::overdraftInfo()
{
    cout << "Cheque account allows overdraft facility.\n";
}
