#include "Customer.h"

void calculateInterest()
{
    Customer c;
    fstream file("customers.dat", ios::binary | ios::in | ios::out);

    cout << "\n    Interest Calculation    \n";

    while(file.read((char*)&c, sizeof(c)))
    {
        double bal = c.getBalance();
        double interest = 0;

        string type = c.getType();

        if(type == "Savings")
            interest = bal * 0.05;   // 5%
        else if(type == "Fixed")
            interest = bal * 0.08;   // 8%
        else if(type == "Student")
            interest = bal * 0.03;   // 3%
        else
            interest = 0;

        bal += interest;
        c.setBalance(bal);

        int pos = -sizeof(c);
        file.seekp(pos, ios::cur);
        file.write((char*)&c, sizeof(c));
    }

    file.close();

    cout << "Interest applied to all accounts.\n";
}
