#include "Account.h.h"

Account.h::Account.h()
{
    //ctor
}

Account.h::~Account.h()
{
    //dtor
}
