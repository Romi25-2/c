#include "Account.h"
#include "Helper.h"

// Base account section
Account::Account() {
    bal = 0.0;
}

// Getters
string Account::getAccNumber() { return accNumber; }
string Account::getName() { return name; }
string Account::getIdNumber() { return idNumber; }
string Account::getContact() { return contact; }
string Account::getEmail() { return email; }
string Account::getAddress() { return address; }
string Account::getDob() { return dob; }
double Account::getBal() { return bal; }
string Account::getBranchCode() { return branchCode; }
string Account::getPinEncrypted() { return pinEncrypted; }

// Setters
void Account::setAccNumber(string num) {
    accNumber = num;
}
void Account::setName(string n) {
    name = n;
}
void Account::setIdNumber(string id) {
    idNumber = id;
}
void Account::setContact(string c) {
    contact = c;
}
void Account::setEmail(string mail) {
    email = mail;
}
void Account::setAddress(string addr) {
    address = addr;
}
void Account::setDob(string date) {
    dob = date;
}
void Account::setBal(double b) {
    bal = b;
}
void Account::setBranchCode(string code) {
    branchCode = code;
}
void Account::setPinEncrypted(string p) {
    pinEncrypted = p;
    // Encryption logic goes in Helper
}

// Overridable base account details
string Account::getAccountType() {
    return "Account";
}
double Account::getInterestRate() {
    return 0;
}

void Account::displayInfo() {
    cout << "Account Number: " << accNumber << endl;
    cout << "Name: " << name << endl;
    cout << "Balance: R" << bal << endl;
}

// Savings account specifics
string SavingsAccount::getAccountType() {
    return "Savings";
}
double SavingsAccount::getInterestRate() {
    return 0.035;
}
double SavingsAccount::getMinimumBalance() {
    return 100;
}

void SavingsAccount::displayInfo() {
    Account::displayInfo();
    cout << "Type: Savings Account (3.5% interest)" << endl;
}

// Cheque account specifics
string ChequeAccount::getAccountType() {
    return "Cheque";
}
double ChequeAccount::getInterestRate() {
    return 0;
}
double ChequeAccount::getMinimumBalance() {
    return 0;
}

void ChequeAccount::displayInfo() {
    Account::displayInfo();
    cout << "Type: Cheque Account (No interest)" << endl;
}

// Fixed deposit account specifics
FixedDepositAccount::FixedDepositAccount() {
    termMonths = 12;
}

string FixedDepositAccount::getAccountType() {
    return "Fixed";
}
double FixedDepositAccount::getInterestRate() {
    return 0.075;
}
double FixedDepositAccount::getMinimumBalance() {
    return 1000;
}
void FixedDepositAccount::setTerm(int months) {
    termMonths = months;
}
int FixedDepositAccount::getTerm() {
    return termMonths;
}

void FixedDepositAccount::displayInfo() {
    Account::displayInfo();
    cout << "Type: Fixed Deposit (7.5% interest, " << termMonths << " months)" << endl;
}

// Student account specifics
string StudentAccount::getAccountType() {
    return "Student";
}
double StudentAccount::getInterestRate() {
    return 0.01;
}
double StudentAccount::getMinimumBalance() {
    return 0;
}

void StudentAccount::displayInfo() {
    Account::displayInfo();
    cout << "Type: Student Account (1% interest, no fees)" << endl;
}
