#include "FileHandler.h"
#include "Account.h"
#include "Teller.h"
#include "Helper.h"
#include <fstream>
#include <sstream>
#include <iostream>
#include <cstring>

// external globals
extern vector<Branch> branches;
extern vector<Account*> accounts;
extern vector<string> transactionHistory;

void saveData() {
    ofstream file("customers.dat", ios::binary);
    if(!file) return;

    for(int i = 0; i < accounts.size(); i++) {
        file << accounts[i]->getAccNumber() << "|"
             << accounts[i]->getName() << "|"
             << accounts[i]->getIdNumber() << "|"
             << accounts[i]->getContact() << "|"
             << accounts[i]->getEmail() << "|"
             << accounts[i]->getAddress() << "|"
             << accounts[i]->getDob() << "|"
             << accounts[i]->getAccountType() << "|"
             << accounts[i]->getBal() << "|"
             << accounts[i]->getBranchCode() << "|"
             << accounts[i]->getPinEncrypted() << "\n";
    }
    file.close();
}

void loadData() {
    ifstream file("customers.dat");
    if(!file) return;

    string line;
    while(getline(file, line)) {
        stringstream ss(line);
        string accNum, name, idNum, contact, email, addr, dob, accType, branch, pin;
        double bal;

        getline(ss, accNum, '|');
        getline(ss, name, '|');
        getline(ss, idNum, '|');
        getline(ss, contact, '|');
        getline(ss, email, '|');
        getline(ss, addr, '|');
        getline(ss, dob, '|');
        getline(ss, accType, '|');
        ss >> bal;
        ss.ignore();
        getline(ss, branch, '|');
        getline(ss, pin, '|');

        Account* newAccount = NULL;
        if(accType == "Savings") newAccount = new SavingsAccount();
        else if(accType == "Cheque") newAccount = new ChequeAccount();
        else if(accType == "Fixed") newAccount = new FixedDepositAccount();
        else if(accType == "Student") newAccount = new StudentAccount();
        else continue;

        newAccount->setAccNumber(accNum);
        newAccount->setName(name);
        newAccount->setIdNumber(idNum);
        newAccount->setContact(contact);
        newAccount->setEmail(email);
        newAccount->setAddress(addr);
        newAccount->setDob(dob);
        newAccount->setBal(bal);
        newAccount->setBranchCode(branch);
        newAccount->setPinEncrypted(pin);

        accounts.push_back(newAccount);
    }
    file.close();
    loadTransactionsFromFile();
}

void saveTransactionsToFile() {
    ofstream file("transactions.dat", ios::binary);
    if(!file) return;

    int count = transactionHistory.size();
    file.write((char*)&count, sizeof(int));

    for(int i = 0; i < transactionHistory.size(); i++) {
        int len = transactionHistory[i].length();
        file.write((char*)&len, sizeof(int));
        file.write(transactionHistory[i].c_str(), len);
    }
    file.close();
}

void loadTransactionsFromFile() {
    ifstream file("transactions.dat", ios::binary);
    if(!file) return;

    transactionHistory.clear();
    int count;
    file.read((char*)&count, sizeof(int));

    for(int i = 0; i < count; i++) {
        int len;
        file.read((char*)&len, sizeof(int));
        char* buffer = new char[len + 1];
        file.read(buffer, len);
        buffer[len] = '\0';
        transactionHistory.push_back(string(buffer));
        delete[] buffer;
    }
    file.close();
}

void exportCustomersToCSV() {
    ofstream file("customers_export.csv");
    file << "Account Number,Name,ID,Contact,Email,Type,Balance\n";

    for(int i = 0; i < accounts.size(); i++) {
        file << accounts[i]->getAccNumber() << ","
             << accounts[i]->getName() << ","
             << accounts[i]->getIdNumber() << ","
             << accounts[i]->getContact() << ","
             << accounts[i]->getEmail() << ","
             << accounts[i]->getAccountType() << ","
             << accounts[i]->getBal() << "\n";
    }
    file.close();
    cout << "Exported to customers_export.csv\n";
}

void exportTransactionsToCSV() {
    ofstream file("transactions_export.csv");
    file << "ID,Description\n";
    for(int i = 0; i < transactionHistory.size(); i++) {
        file << i+1 << "," << transactionHistory[i] << "\n";
    }
    file.close();
    cout << "Exported to transactions_export.csv\n";
}

void exportBranchReportToCSV() {
    ofstream file("branch_report.csv");
    file << "Branch Code,Branch Name,Customers,Total Balance\n";

    for(int b = 0; b < branches.size(); b++) {
        int count = 0;
        double total = 0;
        for(int i = 0; i < accounts.size(); i++) {
            if(accounts[i]->getBranchCode() == branches[b].branchCode) {
                count++;
                total += accounts[i]->getBal();
            }
        }
        file << branches[b].branchCode << ","
             << branches[b].branchName << ","
             << count << ","
             << total << "\n";
    }
    file.close();
    cout << "Exported to branch_report.csv\n";
}

void backupData() {
    cout << "\n    BACKUP    \n";

    ifstream src("customers.dat");
    ofstream dst("backup_customers.dat");
    if(src && dst) dst << src.rdbuf();
    src.close(); dst.close();

    ifstream src2("transactions.dat");
    ofstream dst2("backup_transactions.dat");
    if(src2 && dst2) dst2 << src2.rdbuf();
    src2.close(); dst2.close();

    cout << "Backup complete!\n";
}

void recoverFromBackup() {
    char confirm;
    cout << "Overwrite current data? (y/n): ";
    cin >> confirm;

    if(confirm != 'y') return;

    ifstream backup("backup_customers.dat");
    ofstream current("customers.dat");
    if(backup && current) current << backup.rdbuf();
    backup.close(); current.close();

    accounts.clear();
    transactionHistory.clear();
    loadData();

    cout << "Recovery complete! Restart system.\n";
}
