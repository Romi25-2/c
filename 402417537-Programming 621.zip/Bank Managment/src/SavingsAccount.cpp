#include "SavingsAccount.h"

void SavingsAccount::interestNote()
{
    cout << "Savings Account earns monthly interest.\n";
}
