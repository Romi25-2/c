#include "Helper.h"
#include "Account.h"
#include <sstream>
#include <cstdlib>
#include <ctime>
#include <cctype>

string toStr(double num) {
    stringstream ss;
    ss << num;
    return ss.str();
}

// Just a basic encryption � nothing fancy.
string simpleEncrypt(string txt) {
    string result = txt;
    char key = 0x5A;

    for (int i = 0; i < txt.length(); i++) {
        result[i] = txt[i] ^ key;
    }
    return result;
}

string generateAccNumber(string branchCode) {
    int nextNum = 10000;
    if (!accounts.empty()) {
        nextNum = accounts.size() + 10000;
    }
    stringstream ss;
    ss << "ACC-" << branchCode << "-" << nextNum;
    return ss.str();
}

string generateRandomPin() {
    int pin = 10000 + rand() % 90000;
    stringstream ss;
    ss << pin;
    return ss.str();
}

bool validateSAID(string id) {
    if (id.length() != 13) return false;
    for (int i = 0; i < id.length(); i++) {
        if (!isdigit(id[i])) return false;
    }
    return true;
}

bool validateEmail(string email) {
    bool hasAt = false;
    bool hasDot = false;
    for (int i = 0; i < email.length(); i++) {
        if (email[i] == '@') hasAt = true;
        if (email[i] == '.' && hasAt) hasDot = true;
    }
    return hasAt && hasDot;
}
