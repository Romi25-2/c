#include "Branch.h"

class BranchManager
{
private:
    Branch branches[3]; // at least 3 branches (as required)

public:
    void loadBranches()
    {
        branches[0].setBranch(101, "Cape Town Central", "Cape Town", 25, 1500000);
        branches[1].setBranch(102, "Bellville Branch", "Bellville", 18, 900000);
        branches[2].setBranch(103, "Durbanville Branch", "Durbanville", 12, 600000);
    }

    void viewAll()
    {
        cout << "\n    All Branches    \n";
        for(int i = 0; i < 3; i++)
        {
            branches[i].displayBranch();
        }
    }

    void viewBranch(int code)
    {
        for(int i = 0; i < 3; i++)
        {
            if(branches[i].getCode() == code)
            {
                cout << "\n--- Branch Details ---\n";
                branches[i].displayBranch();
                return;
            }
        }

        cout << "Branch not found.\n";
    }

    void compareBranches()
    {
        cout << "\n--- Branch Comparison (Deposits) ---\n";

        Branch highest = branches[0];

        for(int i = 1; i < 3; i++)
        {
            if(branches[i].getDeposits() > highest.getDeposits())
                highest = branches[i];
        }

        cout << "\nBranch with highest deposits:\n";
        highest.displayBranch();
    }
};
