#include "Transaction.h"

// small helper to encrypt pin same way as Customer
string encryptInputPIN(string pin)
{
    string enc = "";
    for(char c : pin)
        enc += char(c + 4);

    return enc;
}

// verify PIN before any transaction
bool Transaction::verifyPIN(const char* acc)
{
    string pin;
    int attempts = 0;

    Customer c;
    ifstream file("customers.dat", ios::binary);

    while(attempts < 3)
    {
        cout << "Enter PIN: ";
        cin >> pin;

        string enc = encryptInputPIN(pin);

        file.clear();
        file.seekg(0);

        while(file.read((char*)&c, sizeof(c)))
        {
            if(strcmp(c.getAcc(), acc) == 0 &&
               strcmp(c.getPIN(), enc.c_str()) == 0)
            {
                file.close();
                return true;
            }
        }

        attempts++;
        cout << "Wrong PIN. Attempts left: " << (3 - attempts) << endl;
    }

    file.close();
    cout << "Too many failed attempts.\n";
    return false;
}


// ------------------ DEPOSIT ------------------
void Transaction::deposit()
{
    char acc[10];
    double amount;

    try
    {
        cout << "\nEnter Account Number: ";
        cin >> acc;

        if(!verifyPIN(acc))
            throw "PIN verification failed";

        cout << "Enter amount to deposit: ";
        cin >> amount;

        if(amount <= 0)
            throw "Invalid deposit amount";

        fstream file("customers.dat", ios::binary | ios::in | ios::out);
        Customer c;

        while(file.read((char*)&c, sizeof(c)))
        {
            if(strcmp(c.getAcc(), acc) == 0)
            {
                double newBal = c.getBalance() + amount;
                c.setBalance(newBal);

                int pos = -sizeof(c);
                file.seekp(pos, ios::cur);
                file.write((char*)&c, sizeof(c));

                cout << "Deposit successful! New balance: " << newBal << endl;
                file.close();
                return;
            }
        }

        file.close();
        throw "Account not found";
    }
    catch(const char* msg)
    {
        cout << "Error: " << msg << endl;
    }
}


// ------------------ WITHDRAW ------------------
void Transaction::withdraw()
{
    char acc[10];
    double amount;

    try
    {
        cout << "\nEnter Account Number: ";
        cin >> acc;

        if(!verifyPIN(acc))
            throw "PIN verification failed";

        cout << "Enter amount to withdraw: ";
        cin >> amount;

        if(amount <= 0)
            throw "Invalid withdrawal amount";

        fstream file("customers.dat", ios::binary | ios::in | ios::out);
        Customer c;

        while(file.read((char*)&c, sizeof(c)))
        {
            if(strcmp(c.getAcc(), acc) == 0)
            {
                if(amount > c.getBalance())
                    throw "Insufficient funds";

                double newBal = c.getBalance() - amount;
                c.setBalance(newBal);

                int pos = -sizeof(c);
                file.seekp(pos, ios::cur);
                file.write((char*)&c, sizeof(c));

                cout << "Withdrawal successful! New balance: " << newBal << endl;
                file.close();
                return;
            }
        }

        file.close();
        throw "Account not found";
    }
    catch(const char* msg)
    {
        cout << "Error: " << msg << endl;
    }
}


// ------------------ TRANSFER ------------------
void Transaction::transfer()
{
    char fromAcc[10], toAcc[10];
    double amount;

    try
    {
        cout << "\nFrom Account: ";
        cin >> fromAcc;

        if(!verifyPIN(fromAcc))
            throw "PIN verification failed";

        cout << "To Account: ";
        cin >> toAcc;

        cout << "Amount: ";
        cin >> amount;

        if(amount <= 0)
            throw "Invalid transfer amount";

        fstream file("customers.dat", ios::binary | ios::in | ios::out);
        Customer sender, receiver;

        bool foundSender = false, foundReceiver = false;

        // first find sender
        while(file.read((char*)&sender, sizeof(sender)))
        {
            if(strcmp(sender.getAcc(), fromAcc) == 0)
            {
                if(amount > sender.getBalance())
                    throw "Not enough funds";

                double newBal = sender.getBalance() - amount;
                sender.setBalance(newBal);

                int pos = -sizeof(sender);
                file.seekp(pos, ios::cur);
                file.write((char*)&sender, sizeof(sender));

                foundSender = true;
                break;
            }
        }

        // now find receiver
        file.clear();
        file.seekg(0);

        while(file.read((char*)&receiver, sizeof(receiver)))
        {
            if(strcmp(receiver.getAcc(), toAcc) == 0)
            {
                double newBal = receiver.getBalance() + amount;
                receiver.setBalance(newBal);

                int pos = -sizeof(receiver);
                file.seekp(pos, ios::cur);
                file.write((char*)&receiver, sizeof(receiver));

                foundReceiver = true;
                break;
            }
        }

        file.close();

        if(!foundSender || !foundReceiver)
            throw "Transfer failed (account issue)";

        cout << "Transfer completed successfully!\n";
    }
    catch(const char* msg)
    {
        cout << "Error: " << msg << endl;
    }
}


// ------------------ VIEW STATEMENT ------------------
void Transaction::viewStatement()
{
    char acc[10];

    try
    {
        cout << "\nEnter Account Number: ";
        cin >> acc;

        if(!verifyPIN(acc))
            throw "PIN verification failed";

        ifstream file("customers.dat", ios::binary);
        Customer c;

        while(file.read((char*)&c, sizeof(c)))
        {
            if(strcmp(c.getAcc(), acc) == 0)
            {
                cout << "\n--- Account Details ---\n";
                c.showCustomer();
                file.close();
                return;
            }
        }

        file.close();
        throw "Account not found";
    }
    catch(const char* msg)
    {
        cout << "Error: " << msg << endl;
    }
}
