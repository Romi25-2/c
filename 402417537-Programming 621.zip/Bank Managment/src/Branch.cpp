#include "Branch.h"

void Branch::setBranch(int code, const char* name, const char* loc, int emp, double dep)
{
    branchCode = code;
    strcpy(branchName, name);
    strcpy(location, loc);
    numEmployees = emp;
    totalDeposits = dep;
}

int Branch::getCode()
{
    return branchCode;
}

const char* Branch::getName()
{
    return branchName;
}

const char* Branch::getLocation()
{
    return location;
}

int Branch::getEmployees()
{
    return numEmployees;
}

double Branch::getDeposits()
{
    return totalDeposits;
}

void Branch::displayBranch()
{

    cout << "\n Branch Code: " << branchCode;
    cout << "\n Name: " << branchName;
    cout << "\n Location: " << location;
    cout << "\n Employees: " << numEmployees;
    cout << "\n Total Deposits: " << totalDeposits << endl;
}
