#include "Customer.h"

// simple encryption (shift)
string Customer::encryptPIN(string pin)
{
    string enc = "";

    for(int i = 0; i < pin.length(); i++)
    {
        enc += char(pin[i] + 4);
    }

    return enc;
}

// auto account number generator
string Customer::generateAccountNumber()
{
    srand(time(0));
    int num = rand() % 900000 + 100000;
    return "ACC" + to_string(num);
}

// generate 5-digit PIN
string Customer::generatePIN()
{
    int pin = rand() % 90000 + 10000;
    return to_string(pin);
}

void Customer::registerCustomer()
{ // required information
    string acc = generateAccountNumber();
    string pin = generatePIN();

    cout << "\n    Account Registration    \n";
    cout << "Account Number(auto generated, format: ACC-BRANCH-XXXX): " << acc << endl;

    cout << "\n Enter FULL Name: ";
    cin.ignore();
    cin.getline(name, 50);

    cout << "Enter South African ID Number: ";
    cin >> idNumber;

    cout << "Enter Contact Number: ";
    cin >> contact;

    cout << "Enter Email: ";
    cin >> email;

    cout << "Enter Physical Address: ";
    cin.ignore();
    cin.getline(address, 100);

    cout << "Enter Date of Birth (DD/MM/YYYY): ";
    cin >> dob;

    cout << "Account Type (Savings/Cheque/Fixed/Student): ";
    cin >> accountType;

    double dep;
    cout << "Initial Deposit: ";
    cin >> dep;

    cout << "Enter Branch Code: ";
    cin >> branchCode;

    cout << "Generated PIN (save this): " << pin << endl;




    // set account info (from base class)
    setAccountNumber(acc.c_str());
    setBalance(dep);

    string enc = encryptPIN(pin);
    strcpy(pinEncrypted, enc.c_str());

    ofstream file("customers.dat", ios::binary | ios::app);
    file.write((char*)this, sizeof(*this));
    file.close();

    cout << "\nCustomer successfully registered!\n";
}

void Customer::showCustomer()
{
    cout << "\n Account: " << accountNumber;
    cout << "\n Name: " << name;
    cout << "\n Type: " << accountType;
    cout << "\n Balance: " << balance << endl;
}

const char* Customer::getAcc()
{
    return accountNumber;
}

const char* Customer::getPIN()
{
    return pinEncrypted;
}
