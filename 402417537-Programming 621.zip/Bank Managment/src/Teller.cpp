#include "Teller.h"
#include "Helper.h"  // This gives me simpleEncrypt

Teller::Teller() {}

Teller::Teller(string id, string n, string pass, string branch) {
    tellerID = id;
    name = n;
    passwordEncrypted = simpleEncrypt(pass);
    branchCode = branch;
}
