#include "FixedDepositAccount.h"

FixedDepositAccount::lockPeriodInfo()
{
    cout << "Fixed Deposit cannot be withdrawn before maturity.\n";
}
