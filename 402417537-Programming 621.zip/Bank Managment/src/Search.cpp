#include "Customer.h"

void searchCustomer()
{
    char acc[10];
    cout << "\nEnter account number to search: ";
    cin >> acc;

    Customer c;
    ifstream file("customers.dat", ios::binary);

    bool found = false;

    while(file.read((char*)&c, sizeof(c)))
    {
        if(strcmp(c.getAcc(), acc) == 0)
        {
            cout << "\n--- Customer Found ---\n";
            c.showCustomer();
            found = true;
            break;
        }
    }

    file.close();

    if(!found)
        cout << "Customer not found.\n";
}
