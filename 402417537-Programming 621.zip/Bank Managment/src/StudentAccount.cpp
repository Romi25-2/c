#include "StudentAccount.h"

void StudentAccount::studentRules()
{
    cout << "Student account has low fees and limited withdrawals.\n";
}
